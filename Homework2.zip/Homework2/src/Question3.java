import java.util.Scanner;

public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int size = scan.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter the elements of an array...");
		for(int i = 0; i < arr.length; i ++) {
			System.out.print("Enter the element present at an index " + (i) + ":" );
			arr[i] = scan.nextInt();

		}
		System.out.println("Lets sort the array using bubble sort technique...");
		
		for(int i = 0; i < arr.length; i ++)
		{
			for(int j = 1; j < arr.length - i; j++)
			{
				if(arr[j] < arr[j-1])
				{
					int tmp = arr[j];
					arr[j] = arr[j-1];
					arr[j-1] = tmp;
				}
			}
		}
		
		System.out.print("Sorted array is: ");
		for(int ele: arr)
		{
			System.out.print(ele + " ");
		}

		
	}

}
