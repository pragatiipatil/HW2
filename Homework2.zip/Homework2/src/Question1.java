
import java.util.*;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Program to check whether duplicates are present in an array or not
		
		//holds number of duplicates present
		int count = 0;
		
		boolean flag = false;
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int size = scan.nextInt();
		//System.out.println();
		int[] arr = new int[size];
		System.out.println("Enter the elements of an array...");
		for(int i = 0; i < arr.length; i ++) {
			System.out.print("Enter the element present at an index " + (i) + ":" );
			arr[i] = scan.nextInt();

		}
		System.out.println("\nLets find out whether duplicates are present or not...\n");
		for(int i = 0; i < arr.length-1; i++)
		{
			for(int j = i+1; j <  arr.length; j++)
			{
				if(arr[j] == arr[i])
				{
					count++;
					flag = true;
				}
			}
		
		}
		
		if(flag == false)
			System.out.println("No duplicates present");
		else
			System.out.println("duplicates are present and number of duplicates"
					+ " present are " + count);	

	}

}
