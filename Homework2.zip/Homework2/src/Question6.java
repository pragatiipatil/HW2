import java.util.Arrays;

public class Question6 {

	public static void main(String[] args) {
		
		int[] mainArray = {1,2,3,4,5,6,7,8};
		int[] subArray = {1,1};
		Arrays.sort(mainArray);
		Arrays.sort(subArray);
		int count = 0;
		
		for(int i=0; i < subArray.length; i ++)
		{
			for(int j = 0; j < mainArray.length; j ++)
			{
				if(subArray[i] == mainArray[j])
				{
					count++;
				}
			}
		}
		
		if(count == subArray.length)
			System.out.println("subArray is a subset of mainArray");
		else
			System.out.println("subArray is not a subset of mainArray");
		
		

	}

}
